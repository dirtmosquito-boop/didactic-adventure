package com.students.autofishing;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;

public class FishingAccessibilityService extends AccessibilityService {
    public static FishingAccessibilityService instance;
    private WindowManager wm;
    private View panel;
    private final Handler handler = new Handler(Looper.getMainLooper());
    @Override public void onServiceConnected() { super.onServiceConnected(); instance = this; wm = (WindowManager)getSystemService(WINDOW_SERVICE); }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { hideControls(); if (instance == this) instance = null; super.onDestroy(); }

    public void tap(float x, float y) {
        Path path = new Path(); path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path, 0, 65)).build();
        dispatchGesture(gesture, null, null);
    }
    public void showControls() {
        if (panel != null || wm == null) return;
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(8,8,8,8);
        Button left = button("LEFT", () -> tap(getResources().getDisplayMetrics().widthPixels * .18f, getResources().getDisplayMetrics().heightPixels * .76f));
        Button up = button("UP", () -> tap(getResources().getDisplayMetrics().widthPixels * .39f, getResources().getDisplayMetrics().heightPixels * .76f));
        Button down = button("DOWN", () -> tap(getResources().getDisplayMetrics().widthPixels * .61f, getResources().getDisplayMetrics().heightPixels * .76f));
        Button right = button("RIGHT", () -> tap(getResources().getDisplayMetrics().widthPixels * .82f, getResources().getDisplayMetrics().heightPixels * .76f));
        Button close = button("HIDE", this::hideControls);
        box.addView(left); box.addView(up); box.addView(down); box.addView(right); box.addView(close);
        int type = android.os.Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START; params.x = 8; params.y = 140;
        panel = box; wm.addView(panel, params);
    }
    private Button button(String label, Runnable action) { Button b = new Button(this); b.setText(label); b.setOnClickListener(v -> action.run()); return b; }
    public void hideControls() { if (panel != null && wm != null) { try { wm.removeView(panel); } catch (Exception ignored) {} panel = null; } }
}
