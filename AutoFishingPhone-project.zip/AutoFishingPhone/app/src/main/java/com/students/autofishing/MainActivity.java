package com.students.autofishing;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22), dp(28), dp(22), dp(20));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView title = new TextView(this); title.setText("Auto Fishing"); title.setTextSize(28); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(60)));
        TextView info = new TextView(this); info.setText("Phone-only Android app starter\n\n1. Enable the touch service below.\n2. Open your game.\n3. Use the test buttons to check tap positions.\n\nAutomatic minigame recognition is not implemented in this starter yet. It needs screenshots from your game's minigame to tune arrow detection."); info.setTextSize(16); info.setPadding(0,dp(16),0,dp(20));
        root.addView(info, new LinearLayout.LayoutParams(-1, -2));
        Button accessibility = new Button(this); accessibility.setText("Enable accessibility service"); accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessibility, new LinearLayout.LayoutParams(-1, -2));
        Button test = new Button(this); test.setText("Open touch test controls"); test.setOnClickListener(v -> { if (FishingAccessibilityService.instance != null) FishingAccessibilityService.instance.showControls(); else info.setText("Enable Auto Fishing Touch Service in Android Accessibility settings, then return here and try again."); });
        root.addView(test, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }
}
