# Auto Fishing Phone Android project

This is an Android project starter for a phone-only fishing helper. It includes an accessibility service and a floating touch-test panel. It does NOT yet automatically detect or read the fishing minigame arrows, and it does not auto-cast. The original Python image-processing logic needs to be ported and tuned against real screenshots before those features are reliable.

## Build APK online without a computer
1. Create a GitHub account if needed.
2. Create a new repository and upload the contents of this folder.
3. Open the repository's Actions tab.
4. Select **Build Android APK** and press **Run workflow**.
5. When the workflow finishes, open its run and download the `AutoFishing-debug-apk` artifact.
6. Extract the artifact on your phone and install `app-debug.apk`. Android might ask you to allow installs from your browser or file manager.
7. Open Auto Fishing and enable its accessibility service in Android Settings.

## Current state
- Android app shell: included.
- Accessibility gesture service: included.
- Floating touch test buttons: included.
- Automatic screenshot capture, arrow detection, minigame state detection, auto-cast: not implemented yet.

Use the test buttons only to verify that accessibility taps work. The current positions are rough proportions and need calibration to the game layout.
